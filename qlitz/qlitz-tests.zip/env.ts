import * as dotenv from 'dotenv';

export function loadEnv() {
  const env = process.env.ENV || 'dev';
  dotenv.config({ path: `.env.${env}` });

  return {
    baseURL: process.env.BASE_URL || '',
    apiKey: process.env.API_KEY || '',
    bearerToken: process.env.BEARER_TOKEN || ''
  };
}
