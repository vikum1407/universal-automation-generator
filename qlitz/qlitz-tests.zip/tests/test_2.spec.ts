import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('POST /pet', async () => {
  const client = apiClient();
  const response = await client.post('/pet');
  expect(response.status()).toBe(405);
});
