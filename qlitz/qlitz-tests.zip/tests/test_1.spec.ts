import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('POST /pet/{petId}/uploadImage', async () => {
  const client = apiClient();
  const response = await client.post('/pet/{petId}/uploadImage');
  expect(response.status()).toBe(200);
});
