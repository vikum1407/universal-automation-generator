import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('POST /pet/{petId}', async () => {
  const client = apiClient();
  const response = await client.post('/pet/{petId}');
  expect(response.status()).toBe(405);
});
