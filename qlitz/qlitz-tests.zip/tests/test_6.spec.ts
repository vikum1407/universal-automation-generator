import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('GET /pet/{petId}', async () => {
  const client = apiClient();
  const response = await client.get('/pet/{petId}');
  expect(response.status()).toBe(200);
});
