import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('GET /pet/findByTags', async () => {
  const client = apiClient();
  const response = await client.get('/pet/findByTags');
  expect(response.status()).toBe(200);
});
