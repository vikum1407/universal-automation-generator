import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('POST /user/createWithArray', async () => {
  const client = apiClient();
  const response = await client.post('/user/createWithArray');
  expect(response.status()).toBe(200);
});
