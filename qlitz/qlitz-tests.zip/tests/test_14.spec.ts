import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('GET /user/{username}', async () => {
  const client = apiClient();
  const response = await client.get('/user/{username}');
  expect(response.status()).toBe(200);
});
