import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('DELETE /user/{username}', async () => {
  const client = apiClient();
  const response = await client.delete('/user/{username}');
  expect(response.status()).toBe(400);
});
