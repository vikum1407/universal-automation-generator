import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('GET /user/login', async () => {
  const client = apiClient();
  const response = await client.get('/user/login');
  expect(response.status()).toBe(200);
});
