import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('POST /user', async () => {
  const client = apiClient();
  const response = await client.post('/user');
  expect(response.status()).toBe(200);
});
