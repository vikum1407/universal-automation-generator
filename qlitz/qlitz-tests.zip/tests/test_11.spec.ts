import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('GET /store/order/{orderId}', async () => {
  const client = apiClient();
  const response = await client.get('/store/order/{orderId}');
  expect(response.status()).toBe(200);
});
