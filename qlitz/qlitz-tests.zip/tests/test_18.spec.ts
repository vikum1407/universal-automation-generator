import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('GET /user/logout', async () => {
  const client = apiClient();
  const response = await client.get('/user/logout');
  expect(response.status()).toBe(200);
});
