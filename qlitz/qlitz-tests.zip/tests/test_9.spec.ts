import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('GET /store/inventory', async () => {
  const client = apiClient();
  const response = await client.get('/store/inventory');
  expect(response.status()).toBe(200);
});
