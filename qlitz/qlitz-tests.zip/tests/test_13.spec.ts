import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('POST /user/createWithList', async () => {
  const client = apiClient();
  const response = await client.post('/user/createWithList');
  expect(response.status()).toBe(200);
});
