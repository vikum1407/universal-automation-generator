import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('PUT /pet', async () => {
  const client = apiClient();
  const response = await client.put('/pet');
  expect(response.status()).toBe(400);
});
