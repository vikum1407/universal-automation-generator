import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('GET /pet/findByStatus', async () => {
  const client = apiClient();
  const response = await client.get('/pet/findByStatus');
  expect(response.status()).toBe(200);
});
