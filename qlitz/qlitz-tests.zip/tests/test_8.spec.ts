import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('DELETE /pet/{petId}', async () => {
  const client = apiClient();
  const response = await client.delete('/pet/{petId}');
  expect(response.status()).toBe(400);
});
