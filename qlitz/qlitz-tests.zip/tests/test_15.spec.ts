import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('PUT /user/{username}', async () => {
  const client = apiClient();
  const response = await client.put('/user/{username}');
  expect(response.status()).toBe(400);
});
