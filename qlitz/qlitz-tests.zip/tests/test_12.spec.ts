import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('DELETE /store/order/{orderId}', async () => {
  const client = apiClient();
  const response = await client.delete('/store/order/{orderId}');
  expect(response.status()).toBe(400);
});
