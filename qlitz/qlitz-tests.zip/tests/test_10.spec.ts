import { test, expect } from '@playwright/test';
import { apiClient } from '../utils/apiClient';

test('POST /store/order', async () => {
  const client = apiClient();
  const response = await client.post('/store/order');
  expect(response.status()).toBe(200);
});
